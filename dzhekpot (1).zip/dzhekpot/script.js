{
const $ = s => document.querySelector(s);
const rand = (a, b) => a + Math.random() * (b - a), pick = a => a[Math.random() * a.length | 0];
const RM = matchMedia('(prefers-reduced-motion: reduce)').matches;
const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
};

const CARDS = [
  { n: 1, name: 'Начало', a1: '#ff7a59', a2: '#ffb199', text: 'С единицы начинается любой счёт, любой путь и любая история.', facts: ['Единица — ни простое, ни составное число.', 'Любое число, умноженное на 1, остаётся самим собой.'] },
  { n: 2, name: 'Пара', a1: '#5b6cff', a2: '#a5a0ff', text: 'Двое — это уже диалог, ритм и равновесие.', facts: ['2 — единственное чётное простое число.', 'Двоичная система из нулей и единиц лежит в основе всех компьютеров.'] },
  { n: 3, name: 'Треугольник', a1: '#14b89a', a2: '#7ee2c8', text: 'Три точки — и появляется форма. Треугольник — самая жёсткая фигура: его нельзя сложить, не сломав сторону.', facts: ['Через три точки, не лежащие на одной прямой, проходит ровно одна плоскость.', 'Сумма углов треугольника на плоскости — 180°.'] },
  { n: 4, name: 'Времена года', a1: '#f59e0b', a2: '#fcd57a', text: 'Зима, весна, лето, осень — круг, который повторяется каждый год.', facts: ['Сторон света тоже четыре: север, юг, запад и восток.', 'У квадрата четыре равные стороны и четыре прямых угла.'] },
  { n: 5, name: 'Звезда', a1: '#f43f7a', a2: '#ff9fc0', text: 'Соедините пять точек через одну — и звезда нарисуется одним росчерком.', facts: ['У большинства морских звёзд пять лучей.', 'На руке человека пять пальцев.'] },
  { n: 6, name: 'Соты', a1: '#eaa21a', a2: '#ffd166', text: 'Пчёлы строят соты из шестиугольников — это самая экономная форма для хранения мёда.', facts: ['Шестиугольники заполняют плоскость без зазоров при наименьшей общей длине стенок.', 'У снежинок шесть лучей.'] },
  { n: 7, name: 'Радуга', a1: '#6a7bff', a2: '#ff7ac6', text: 'Семь цветов радуги — от красного до фиолетового.', facts: ['В неделе семь дней.', 'В музыкальной гамме семь нот: до, ре, ми, фа, соль, ля, си.'] },
  { n: 8, name: 'Бесконечность', a1: '#2f9bf0', a2: '#8fd3ff', text: 'Положите восьмёрку на бок — и получится знак бесконечности.', facts: ['Знак ∞ ввёл английский математик Джон Валлис в 1655 году.', 'У паука восемь ног.'] },
  { n: 9, name: 'Квадрат', a1: '#8b5cf6', a2: '#c4b5fd', text: 'Девять — это три по три: самая аккуратная сетка.', facts: ['9 = 3², то есть три в квадрате.', 'Если число делится на 9, то и сумма его цифр делится на 9.'] },
  { n: 10, name: 'ДЖЕКПОТ', a1: '#7c5cff', a2: '#ff6ad5', jp: true }
];
const WISHES = [
  'Пусть сегодня всё получится с первого раза.',
  'Пусть рядом будут люди, с которыми легко.',
  'Пусть маленькая радость найдёт вас уже сегодня.',
  'Пусть задуманное сбудется в самый подходящий момент.',
  'Пусть в этой неделе будет больше света и меньше спешки.',
  'Пусть хорошие новости приходят одна за другой.',
  'Пусть смелая идея станет началом чего-то большого.',
  'Пусть вечер будет тёплым, а утро — бодрым.',
  'Пусть всё важное складывается само собой.',
  'Пусть вдохновение приходит, когда оно нужнее всего.',
  'Пусть этот день запомнится чем-то хорошим.',
  'Пусть удача будет на вашей стороне — во всём.'
];
const hashOf = n => n === 10 ? 'dzhekpot' : 'karta-' + n;
const ICON = {
  go: '<svg viewBox="0 0 24 24"><path d="M7 17 17 7"/><path d="M8 7h9v9"/></svg>',
  ok: '<svg viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>'
};

/* ---------- мягкие звуки ---------- */
const Snd = {
  ctx: null, on: store.get('dz-sound', true),
  init() {
    if (!this.ctx) { const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return; try { this.ctx = new AC(); } catch (e) { return; } }
    if (this.ctx.state === 'suspended') this.ctx.resume().catch(() => {});
  },
  tone(f, d = .5, vol = .06, when = 0, type = 'sine') {
    if (!this.on || !this.ctx) return;
    const c = this.ctx, t = c.currentTime + when, o = c.createOscillator(), g = c.createGain();
    o.type = type; o.frequency.value = f;
    g.gain.setValueAtTime(.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + .015); g.gain.exponentialRampToValueAtTime(.0001, t + d);
    o.connect(g); g.connect(c.destination); o.start(t); o.stop(t + d + .05);
  },
  open(n) { const f = 392 * 2 ** ([0, 2, 4, 5, 7, 9, 11, 12, 14][(n - 1) % 9] / 12); this.tone(f, .5, .06); this.tone(f * 1.5, .6, .04, .09); },
  close() { this.tone(523, .25, .04); this.tone(392, .35, .04, .07); },
  tick() { this.tone(880, .12, .03, 0, 'triangle'); },
  bells() { [523, 659, 784, 988, 1047].forEach((f, i) => { this.tone(f, 1.2, .05, i * .09); this.tone(f * 2, .6, .012, i * .09, 'triangle'); }); }
};

/* ---------- сетка ---------- */
const grid = $('#grid');
grid.innerHTML = CARDS.map((d, i) => d.jp
  ? `<button class="card jp" type="button" data-n="10" style="--i:${i}" aria-label="ДЖЕКПОТ — особая карточка"><span class="ctop"><svg class="star" viewBox="0 0 100 100" aria-hidden="true"><use href="#spark"/></svg><span class="go">${ICON.go}</span></span><span class="cbot"><span><span class="jpname">ДЖЕКПОТ</span><span class="jpsub" style="display:block">Особая карточка</span></span><span class="seen">${ICON.ok}</span></span></button>`
  : `<button class="card" type="button" data-n="${d.n}" style="--a1:${d.a1};--a2:${d.a2};--i:${i}" aria-label="Карточка ${d.n}: ${d.name}"><span class="blob"></span><span class="ctop"><span class="num">${d.n}</span><span class="go">${ICON.go}</span></span><span class="cbot"><span class="name">${d.name}</span><span class="seen">${ICON.ok}</span></span></button>`
).join('');
const cards = [...grid.querySelectorAll('.card')];

let visited = new Set(store.get('dz-visited', []).filter(n => n >= 1 && n <= 10));
function renderProgress() {
  cards.forEach(el => el.classList.toggle('is-seen', visited.has(+el.dataset.n)));
  $('#cnt').textContent = `${visited.size} / 10`;
  $('#ringFg').style.strokeDashoffset = 56.5 * (1 - visited.size / 10);
  $('#reset').hidden = visited.size === 0;
}
renderProgress();
$('#reset').addEventListener('click', () => { visited.clear(); store.set('dz-visited', []); renderProgress(); Snd.close(); });
cards.forEach(el => el.addEventListener('click', () => { if (!spinning) open(+el.dataset.n); }));
let spinning = false;
$('#home').addEventListener('click', e => { e.preventDefault(); scrollTo({ top: 0, behavior: 'smooth' }); });

/* ---------- иллюстрации ---------- */
const GR = '<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" style="stop-color:var(--a1)"/><stop offset="1" style="stop-color:var(--a2)"/></linearGradient></defs>';
const svg = b => `<svg viewBox="0 0 300 300" aria-hidden="true">${GR}${b}</svg>`;
const poly = (cx, cy, r, k, rot) => Array.from({ length: k }, (_, i) => { const a = (rot + i * 360 / k) * Math.PI / 180; return [cx + r * Math.cos(a), cy + r * Math.sin(a)]; });
const VIS = {
  1: () => svg([0, 1, 2].map(i => `<circle class="ripple" cx="150" cy="150" r="52" style="stroke:var(--a1);--d:${i}s"/>`).join('') + '<circle class="breathe" cx="150" cy="150" r="52" fill="url(#g)"/>'),
  2: () => svg('<circle cx="150" cy="150" r="72" fill="none" style="stroke:var(--a1);opacity:.35" stroke-width="2" stroke-dasharray="3 9"/><g class="orbit"><circle class="pop" cx="78" cy="150" r="34" fill="url(#g)"/><circle class="pop" cx="222" cy="150" r="34" style="fill:var(--a2);opacity:.75;--d:.15s"/></g>'),
  3: () => svg('<path class="fillin" pathLength="1" d="M150 50 L254 228 L46 228 Z" fill="url(#g)" style="stroke:var(--a1)" stroke-width="5" stroke-linejoin="round" stroke-dasharray="1" stroke-dashoffset="1"/>' + [[150, 50], [254, 228], [46, 228]].map((p, i) => `<circle class="pop" cx="${p[0]}" cy="${p[1]}" r="10" fill="#fff" style="stroke:var(--a1);--d:${1.1 + i * .15}s" stroke-width="4"/>`).join('')),
  4: () => svg([['Зима', '#8fb8ff', 40, 40], ['Весна', '#7fdca5', 156, 40], ['Лето', '#ffd166', 156, 156], ['Осень', '#ff9b6b', 40, 156]].map((s, i) => `<g class="pop lift" style="--d:${i * .12}s"><rect x="${s[2]}" y="${s[3]}" width="104" height="104" rx="26" fill="${s[1]}"/><text x="${s[2] + 52}" y="${s[3] + 58}" text-anchor="middle" font-family="Onest,sans-serif" font-weight="600" font-size="15" fill="#1b1d24">${s[0]}</text></g>`).join('')),
  5: () => { const v = poly(150, 160, 112, 5, -90), o = [0, 2, 4, 1, 3]; return svg(`<path class="draw" pathLength="1" d="M${o.map(i => v[i].map(x => x.toFixed(1)).join(' ')).join(' L')} Z" fill="none" stroke="url(#g)" stroke-width="6" stroke-linejoin="round"/>` + v.map((p, i) => `<circle class="pop" cx="${p[0].toFixed(1)}" cy="${p[1].toFixed(1)}" r="11" fill="#fff" style="stroke:var(--a1);--d:${.15 + i * .2}s" stroke-width="4"/>`).join('')); },
  6: () => { const c = [[150, 150], ...poly(150, 150, 62, 6, 0)]; return svg(c.map((p, i) => `<polygon class="pop lift" points="${poly(p[0], p[1], 34, 6, 30).map(q => q.map(x => x.toFixed(1)).join(',')).join(' ')}" fill="url(#g)" style="opacity:${i ? .55 + (i % 3) * .15 : 1};--d:${i * .09}s"/>`).join('')); },
  7: () => svg(['#ff6b6b', '#ffa94d', '#ffd43b', '#69db7c', '#4dabf7', '#5c7cfa', '#9775fa'].map((col, i) => { const r = 124 - i * 13; return `<path class="draw" pathLength="1" d="M${150 - r} 212 A${r} ${r} 0 0 1 ${150 + r} 212" fill="none" stroke="${col}" stroke-width="9" stroke-linecap="round" style="--d:${i * .12}s"/>`; }).join('')),
  8: () => { let d = ''; for (let k = 0; k <= 120; k++) { const t = k / 120 * Math.PI * 2, s = Math.sin(t), den = 1 + s * s; d += (k ? 'L' : 'M') + (150 + 118 * Math.cos(t) / den).toFixed(1) + ' ' + (150 + 118 * s * Math.cos(t) / den).toFixed(1); } return svg(`<path class="draw" pathLength="1" d="${d}Z" fill="none" stroke="url(#g)" stroke-width="10" stroke-linecap="round"/><circle r="11" fill="#fff" style="stroke:var(--a1)" stroke-width="4"><animateMotion dur="3.4s" repeatCount="indefinite" path="${d}Z"/></circle>`); },
  9: () => { let b = ''; for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) b += `<rect class="pop lift" x="${44 + j * 76}" y="${44 + i * 76}" width="60" height="60" rx="16" fill="url(#g)" style="opacity:${.45 + (i + j) * .13};--d:${(i + j) * .12}s"/>`; return svg(b); },
  10: () => `<svg viewBox="0 0 300 300" aria-hidden="true"><g fill="#fff"><use class="slow" href="#spark" x="70" y="70" width="160" height="160" style="filter:drop-shadow(0 10px 30px rgba(80,20,140,.35))"/>${[[40, 50, 34, 0], [222, 64, 26, .6], [214, 214, 38, 1.1], [56, 220, 22, 1.6]].map(s => `<use class="tw" href="#spark" x="${s[0]}" y="${s[1]}" width="${s[2]}" height="${s[2]}" style="--d:${s[3]}s"/>`).join('')}</g></svg>`
};

/* ---------- открытая карточка ---------- */
const ov = $('#ov'), panel = $('#panel'), pbody = $('#pbody'), scrim = $('#scrim'), page = $('#page');
let cur = 0, lockUntil = 0;
const isBusy = () => performance.now() < lockUntil, lock = ms => { lockUntil = performance.now() + ms; };
function setHash(h) { try { history.replaceState(null, '', h ? '#' + h : location.pathname + location.search); } catch (e) {} }

function content(d) {
  const stage = `<div class="stage${d.jp ? ' jp' : ''}" id="stage" role="button" tabindex="0" aria-label="Повторить анимацию">${VIS[d.n]()}<span class="hint">Нажмите, чтобы повторить</span></div>`;
  if (d.jp) {
    const all = visited.size === 10;
    return `<div class="pgrid">${stage}<div class="in">
      <div class="bignum word">ДЖЕКПОТ</div>
      <h2 class="ptitle" id="pTitle">Особая карточка</h2>
      <p class="ptext">Иногда всё складывается идеально. Эта карточка — про такие моменты: возьмите с собой пожелание на сегодня.</p>
      <div class="wish"><div class="wl">Пожелание дня</div><p class="wt" id="wish">${pick(WISHES)}</p>
        <button class="btn" id="more" type="button"><svg viewBox="0 0 24 24"><path d="M20 12a8 8 0 1 1-2.3-5.7"/><path d="M20 4v5h-5"/></svg>Новое пожелание</button></div>
      <div class="meter">${all ? 'Коллекция собрана полностью — вы открыли все 10 карточек!' : `Вы открыли ${visited.size} из 10 карточек`}<div class="bar"><i style="width:${visited.size * 10}%"></i></div></div>
    </div></div>`;
  }
  return `<div class="pgrid">${stage}<div class="in">
    <div class="bignum">${d.n}</div>
    <h2 class="ptitle" id="pTitle">${d.name}</h2>
    <p class="ptext">${d.text}</p>
    <ul class="facts">${d.facts.map(f => `<li>${f}</li>`).join('')}</ul>
  </div></div>`;
}
function fill(n) {
  const d = CARDS[n - 1];
  cur = n;
  panel.style.setProperty('--a1', d.a1); panel.style.setProperty('--a2', d.a2);
  if (!visited.has(n)) { visited.add(n); store.set('dz-visited', [...visited]); renderProgress(); }
  pbody.innerHTML = content(d); pbody.scrollTop = 0;
  $('#count').textContent = `${n} из 10`;
  const st = $('#stage');
  const replay = () => { st.innerHTML = VIS[d.n]() + '<span class="hint">Нажмите, чтобы повторить</span>'; Snd.tick(); if (d.jp) burstFrom(st, 60); };
  st.addEventListener('click', replay);
  st.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); replay(); } });
  if (d.jp) {
    $('#more').addEventListener('click', () => {
      const w = $('#wish'); let t; do { t = pick(WISHES); } while (t === w.textContent);
      w.classList.add('swap'); setTimeout(() => { w.textContent = t; w.classList.remove('swap'); }, 220);
      Snd.tick(); burstFrom($('#more'), 40);
    });
  }
  setHash(hashOf(n));
}
function rectAnim(r, pr) {
  const sx = r.width / pr.width, sy = r.height / pr.height;
  return { transform: `translate(${r.left - pr.left}px,${r.top - pr.top}px) scale(${sx},${sy})`, borderRadius: `${22 / sx}px / ${22 / sy}px` };
}
function open(n) {
  Snd.init();
  if (isBusy()) return;
  if (!ov.hidden) { go(n > cur ? 1 : -1, n); return; }
  const from = cards[n - 1];
  ov.hidden = false; document.body.classList.add('lock'); page.inert = true;
  fill(n);
  Snd.open(n);
  if (CARDS[n - 1].jp) { Snd.bells(); setTimeout(() => burstFrom($('#stage'), 110), RM ? 0 : 420); }
  if (!RM) {
    lock(520);
    const pr = panel.getBoundingClientRect(), r = from.getBoundingClientRect(), endR = getComputedStyle(panel).borderRadius;
    from.style.visibility = 'hidden';
    scrim.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 400, easing: 'ease-out' });
    pbody.animate([{ opacity: 0 }, { opacity: 0, offset: .45 }, { opacity: 1 }], { duration: 560 });
    panel.animate([rectAnim(r, pr), { transform: 'none', borderRadius: endR }], { duration: 560, easing: 'cubic-bezier(.2,.85,.25,1)' });
    setTimeout(() => { from.style.visibility = ''; }, 600);
  }
  setTimeout(() => $('#back').focus({ preventScroll: true }), 60);
}
function close() {
  if (ov.hidden || isBusy()) return;
  Snd.close();
  const card = cards[cur - 1];
  const done = () => { ov.hidden = true; card.style.visibility = ''; document.body.classList.remove('lock'); page.inert = false; card.focus({ preventScroll: true }); };
  setHash('');
  if (RM) return done();
  lock(500);
  document.body.classList.remove('lock'); page.inert = false;
  const pr = panel.getBoundingClientRect(), r = card.getBoundingClientRect();
  card.style.visibility = 'hidden';
  pbody.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 160, fill: 'forwards' });
  scrim.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 460, fill: 'forwards' });
  const a = panel.animate([{ transform: 'none', borderRadius: getComputedStyle(panel).borderRadius }, rectAnim(r, pr)], { duration: 480, easing: 'cubic-bezier(.5,0,.2,1)', fill: 'forwards' });
  setTimeout(() => { done(); a.cancel(); pbody.getAnimations().forEach(x => x.cancel()); scrim.getAnimations().forEach(x => x.cancel()); }, 490);
}
function go(dir, target) {
  if (isBusy() || ov.hidden) return;
  const n = target || ((cur - 1 + dir + 10) % 10) + 1;
  Snd.open(n);
  if (RM) { fill(n); return; }
  lock(300);
  pbody.animate([{ opacity: 1, transform: 'none' }, { opacity: 0, transform: `translateX(${-dir * 28}px)` }], { duration: 160, easing: 'ease-in', fill: 'forwards' });
  setTimeout(() => {
    pbody.getAnimations().forEach(x => x.cancel());
    fill(n);
    pbody.animate([{ opacity: 0, transform: `translateX(${dir * 28}px)` }, { opacity: 1, transform: 'none' }], { duration: 320, easing: 'cubic-bezier(.2,.85,.25,1)' });
    if (CARDS[n - 1].jp) { Snd.bells(); setTimeout(() => burstFrom($('#stage'), 100), 200); }
  }, 170);
}
$('#back').addEventListener('click', close);
scrim.addEventListener('click', close);
$('#prev').addEventListener('click', () => go(-1));
$('#next').addEventListener('click', () => go(1));
document.addEventListener('keydown', e => {
  if (!rv.hidden && e.key === 'Escape') { e.preventDefault(); hideResult(); return; }
  if (ov.hidden) return;
  if (e.key === 'Escape') { e.preventDefault(); close(); }
  else if (e.key === 'ArrowRight') go(1);
  else if (e.key === 'ArrowLeft') go(-1);
});
let sx0 = 0, sy0 = 0;
panel.addEventListener('touchstart', e => { sx0 = e.touches[0].clientX; sy0 = e.touches[0].clientY; }, { passive: true });
panel.addEventListener('touchend', e => { const dx = e.changedTouches[0].clientX - sx0, dy = e.changedTouches[0].clientY - sy0; if (Math.abs(dx) > 70 && Math.abs(dy) < 50) go(dx < 0 ? 1 : -1); }, { passive: true });
addEventListener('hashchange', () => {
  const h = location.hash.slice(1), d = CARDS.find(c => hashOf(c.n) === h);
  if (d && (ov.hidden || cur !== d.n)) open(d.n); else if (!d && !ov.hidden) close();
});


/* ---------- вращение ---------- */
const spinBtn = $('#spin'), spinTxt = $('#spinTxt'), tBadge = $('#tBadge'), tLabel = $('#tLabel'), tName = $('#tName'), hist = $('#hist'), rv = $('#rv'), rCard = $('#rCard');
const STAR = '<svg viewBox="0 0 100 100" aria-hidden="true"><use href="#spark"/></svg>';
const SHORT = { 1: 'С единицы начинается любой счёт и любая история.', 10: 'Особая карточка! Сегодня всё складывается идеально.' };
let pos = -1, history10 = store.get('dz-history', []).filter(n => n >= 1 && n <= 10).slice(0, 8), lastResult = 0;
// честный случайный выбор: равный шанс 1/10 для каждой карточки
function fairPick() {
  try {
    const buf = new Uint32Array(1), lim = 4294967290; // кратно 10
    do { crypto.getRandomValues(buf); } while (buf[0] >= lim);
    return buf[0] % 10;
  } catch (e) { return Math.random() * 10 | 0; }
}
function badge(el, d) {
  el.style.setProperty('--a1', d.a1); el.style.setProperty('--a2', d.a2);
  el.innerHTML = d.jp ? STAR : d.n;
}
function light(i) {
  cards.forEach((c, k) => c.classList.toggle('lit', k === i));
  const d = CARDS[i];
  badge(tBadge, d); tName.textContent = d.jp ? 'ДЖЕКПОТ' : `${d.n} · ${d.name}`;
  if (!RM) tBadge.animate([{ transform: 'translateY(-8px) scale(.85)', opacity: .4 }, { transform: 'none', opacity: 1 }], { duration: 130, easing: 'ease-out' });
}
function renderHist() {
  hist.hidden = !history10.length;
  hist.innerHTML = 'Последние:' + history10.map(n => { const d = CARDS[n - 1]; return `<button class="hdot" type="button" data-n="${n}" style="--a1:${d.a1};--a2:${d.a2}" aria-label="Открыть: ${d.jp ? 'ДЖЕКПОТ' : n + ' · ' + d.name}">${d.jp ? STAR : n}</button>`; }).join('');
}
hist.addEventListener('click', e => { const b = e.target.closest('.hdot'); if (b && !spinning) openFromGrid(+b.dataset.n); });
renderHist();
function setBusy(on) {
  spinning = on;
  spinBtn.setAttribute('aria-busy', String(on));
  spinTxt.textContent = on ? 'КРУТИМ…' : 'КРУТИТЬ';
  grid.classList.toggle('spinning', on);
}
/* выбор времени вращения: 1–60 секунд */
const durBox = $('#dur'), segBtns = [...durBox.querySelectorAll('.seg button')], ownIn = $('#ownIn'), own = $('#own'), tProg = $('#tProg');
let spinSec = Math.min(60, Math.max(1, +store.get('dz-sec', 5) || 5));
function renderDur() {
  const preset = segBtns.some(b => +b.dataset.s === spinSec);
  segBtns.forEach(b => b.setAttribute('aria-pressed', String(+b.dataset.s === spinSec)));
  own.classList.toggle('on', !preset);
  if (!preset) ownIn.value = spinSec; else if (document.activeElement !== ownIn) ownIn.value = '';
  $('#note').innerHTML = `Вращение длится ${spinSec}&nbsp;с. У всех 10 карточек одинаковый шанс —&nbsp;по&nbsp;10&nbsp;%.`;
}
function setSec(v) { spinSec = Math.min(60, Math.max(1, Math.round(v))); store.set('dz-sec', spinSec); renderDur(); }
segBtns.forEach(b => b.addEventListener('click', () => { Snd.init(); Snd.tick(); ownIn.value = ''; setSec(+b.dataset.s); }));
ownIn.addEventListener('input', () => { const v = parseInt(ownIn.value, 10); if (v >= 1 && v <= 60) { spinSec = v; store.set('dz-sec', v); segBtns.forEach(b => b.setAttribute('aria-pressed', 'false')); own.classList.add('on'); $('#note').innerHTML = `Вращение длится ${v}&nbsp;с. У всех 10 карточек одинаковый шанс —&nbsp;по&nbsp;10&nbsp;%.`; } });
ownIn.addEventListener('change', () => { const v = parseInt(ownIn.value, 10); setSec(isNaN(v) ? spinSec : v); });
ownIn.addEventListener('keydown', e => { if (e.key === 'Enter') { ownIn.blur(); } });
renderDur();

let cdIv = 0;
function spin() {
  if (spinning || !ov.hidden) return;
  if (document.activeElement === ownIn) ownIn.blur();
  Snd.init();
  setBusy(true);
  durBox.classList.add('locked');
  cards.forEach(c => c.classList.remove('win'));
  const target = fairPick();
  const start = pos < 0 ? 9 : pos;
  // длительность всего вращения = выбранные секунды (последняя пауза входит в них)
  const T = spinSec * 1000, PAUSE = Math.min(380, T * .12), run = T - PAUSE;
  const shape = k => 42 + 420 * Math.pow(k, 2.8);           // быстро → медленно
  const avg = 42 + 420 / 3.8;
  let N = Math.max(10, Math.round(run / avg));
  N += (target - (start + N) % 10 + 10) % 10;                 // остановка ровно на выбранной карточке
  const raw = Array.from({ length: N }, (_, k) => k === 0 ? 0 : shape(k / N));
  const sum = raw.reduce((a, b) => a + b, 0), scale = run / sum;
  const at = []; let acc = 0; for (const d of raw) { acc += d * scale; at.push(acc); }
  const t0 = performance.now();
  tLabel.textContent = 'Выбираем…';
  const tick = () => {
    const left = Math.max(0, T - (performance.now() - t0));
    spinTxt.textContent = `КРУТИМ… ${Math.ceil(left / 1000)}`;
    tProg.style.width = (100 * (1 - left / T)) + '%';
  };
  tick(); cdIv = setInterval(tick, 100);
  let i = 0;
  const step = () => {
    i++; pos = (start + i) % 10; light(pos);
    Snd.tone(520 + (pos * 38), .07, .03, 0, 'triangle');
    if (i >= N) return later(() => finish(pos + 1), Math.max(0, t0 + T - performance.now()));
    later(step, Math.max(0, t0 + at[i] - performance.now()));
  };
  step();
}
const later = (fn, ms) => setTimeout(fn, ms);
function finish(n) {
  clearInterval(cdIv); tProg.style.width = '100%'; setTimeout(() => { tProg.style.width = '0'; }, 600);
  durBox.classList.remove('locked');
  const d = CARDS[n - 1], el = cards[n - 1];
  lastResult = n;
  tLabel.textContent = 'Выпало';
  history10 = [n, ...history10].slice(0, 8); store.set('dz-history', history10); renderHist();
  el.classList.remove('lit'); void el.offsetWidth; el.classList.add('win', 'lit');
  setTimeout(() => el.classList.remove('lit'), 1800);
  grid.classList.remove('spinning');
  if (d.jp) Snd.bells(); else Snd.open(n);
  showResult(d);
  spinning = false;
  spinBtn.setAttribute('aria-busy', 'false');
  spinTxt.textContent = 'КРУТИТЬ';
}
function showResult(d) {
  rCard.classList.remove('out');
  rCard.classList.toggle('jp', !!d.jp);
  rCard.style.setProperty('--a1', d.a1); rCard.style.setProperty('--a2', d.a2);
  $('#rLabel').textContent = d.jp ? 'Невероятно! Вам выпал' : 'Вам выпала карточка';
  $('#rBig').innerHTML = d.jp ? STAR : d.n;
  $('#rTitle').textContent = d.jp ? 'ДЖЕКПОТ' : d.name;
  $('#rText').textContent = SHORT[d.n] || d.text;
  rv.hidden = false; document.body.classList.add('lock');
  // перезапуск анимаций карточки результата
  for (const el of [rCard, $('#rBig')]) { el.style.animation = 'none'; void el.offsetWidth; el.style.animation = ''; }
  setTimeout(() => burstFrom($('#rBig'), d.jp ? 160 : 60), RM ? 0 : 250);
  setTimeout(() => $('#rAgain').focus({ preventScroll: true }), 80);
}
function hideResult(then) {
  if (rv.hidden) return;
  rCard.classList.add('out');
  setTimeout(() => { rv.hidden = true; rCard.classList.remove('out'); document.body.classList.remove('lock'); if (then) then(); else spinBtn.focus({ preventScroll: true }); }, RM ? 0 : 230);
}
function openFromGrid(n) {
  const el = cards[n - 1], r = el.getBoundingClientRect();
  if (r.top < 60 || r.bottom > innerHeight) el.scrollIntoView({ block: 'center', behavior: 'instant' });
  open(n);
}
spinBtn.addEventListener('click', spin);
$('#rAgain').addEventListener('click', () => hideResult(() => setTimeout(spin, 120)));
$('#rOpen').addEventListener('click', () => hideResult(() => openFromGrid(lastResult)));
$('#rClose').addEventListener('click', () => hideResult());
$('#rScrim').addEventListener('click', () => hideResult());

/* ---------- мягкое конфетти ---------- */
const cv = $('#cf'), cx = cv.getContext('2d');
const CF = ['#7c5cff', '#a99bff', '#ff6ad5', '#ffb3e6', '#ffb86b', '#ffe0b8', '#7ee2c8'];
let parts = [], cfRaf = 0, cfLast = 0;
function cfSize() { const dpr = Math.min(devicePixelRatio || 1, 2); cv.width = innerWidth * dpr; cv.height = innerHeight * dpr; cx.setTransform(dpr, 0, 0, dpr, 0, 0); }
function burstFrom(el, n) {
  if (RM) return;
  const r = el.getBoundingClientRect(), x = r.left + r.width / 2, y = r.top + r.height / 2;
  for (let i = 0; i < n; i++) { const a = rand(0, Math.PI * 2), v = rand(180, 620); parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 220, rot: rand(0, 6), vr: rand(-6, 6), s: rand(5, 10), round: Math.random() < .4, col: pick(CF), life: rand(1.6, 2.6), tilt: rand(0, 6) }); }
  if (!cfRaf) { cfSize(); cfLast = 0; cfRaf = requestAnimationFrame(cfLoop); }
}
function cfLoop(t) {
  const dt = Math.min(.04, cfLast ? (t - cfLast) / 1000 : .016); cfLast = t;
  cx.clearRect(0, 0, innerWidth, innerHeight);
  const k = Math.pow(.96, dt * 60);
  for (let i = parts.length - 1; i >= 0; i--) {
    const p = parts[i]; p.life -= dt;
    if (p.life <= 0 || p.y > innerHeight + 30) { parts.splice(i, 1); continue; }
    p.vx *= k; p.vy = (p.vy + 520 * dt) * k; p.x += p.vx * dt; p.y += p.vy * dt; p.rot += p.vr * dt; p.tilt += dt * 6;
    cx.save(); cx.globalAlpha = Math.min(1, p.life * 1.5); cx.translate(p.x, p.y); cx.rotate(p.rot); cx.scale(1, Math.cos(p.tilt)); cx.fillStyle = p.col;
    if (p.round) { cx.beginPath(); cx.arc(0, 0, p.s / 2, 0, 6.283); cx.fill(); } else { cx.beginPath(); cx.roundRect ? cx.roundRect(-p.s / 2, -p.s * .35, p.s, p.s * .7, 2) : cx.rect(-p.s / 2, -p.s * .35, p.s, p.s * .7); cx.fill(); }
    cx.restore();
  }
  cfRaf = parts.length ? requestAnimationFrame(cfLoop) : 0;
  if (!cfRaf) cx.clearRect(0, 0, innerWidth, innerHeight);
}

/* ---------- звук ---------- */
const sndBtn = $('#snd');
function renderSnd() { sndBtn.classList.toggle('muted', !Snd.on); sndBtn.setAttribute('aria-pressed', String(Snd.on)); sndBtn.setAttribute('aria-label', Snd.on ? 'Выключить звук' : 'Включить звук'); }
sndBtn.addEventListener('click', () => { Snd.on = !Snd.on; store.set('dz-sound', Snd.on); Snd.init(); renderSnd(); Snd.tick(); });
renderSnd();
document.addEventListener('pointerdown', () => Snd.init(), { passive: true });

/* ---------- загрузка ---------- */
const dots = $('#ldDots');
dots.innerHTML = '<i></i>'.repeat(10);
const di = [...dots.children];
const fonts = Promise.race([document.fonts ? document.fonts.ready : Promise.resolve(), new Promise(r => setTimeout(r, 2200))]);
let step = 0;
const iv = setInterval(() => { if (step < 10) di[step++].classList.add('on'); }, RM ? 10 : 95);
Promise.all([fonts, new Promise(r => setTimeout(r, RM ? 120 : 1050))]).then(() => {
  di.forEach(d => d.classList.add('on')); clearInterval(iv);
  setTimeout(() => {
    $('#loader').classList.add('done'); document.body.classList.add('ready');
    const h = location.hash.slice(1), d = CARDS.find(c => hashOf(c.n) === h);
    if (d) setTimeout(() => open(d.n), 700);
  }, 250);
});
}
